import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

interface Restaurant {
  name: string;
  foodItems: string[];
}

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.css']
})
export class RestaurantComponent implements OnInit {
  foodItem: string = '';
  restaurants: Restaurant[] = [
    { name: 'Pulse', foodItems: ['Pizza', 'Burger', 'Biryani', 'cool drinks'] },
    { name: 'Pizza Hut', foodItems: ['Pizza', 'Pasta'] },
    { name: 'Chillies', foodItems: ['Pizza', 'Burger'] },
    { name: 'Table 9', foodItems: ['Mutton', 'Biryani', 'cool drinks'] },
    { name: 'Rayalaseema Ruchulu', foodItems: ['Biryani', 'Chicken'] },
    { name: 'Ps4', foodItems: ['Idly', 'Dosa', 'cool drinks'] }
  ];
  filteredRestaurants: Restaurant[] = [];

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Get the selected food item from the route
    this.route.params.subscribe(params => {
      this.foodItem = params['foodItem'];
      this.filteredRestaurants = this.getFilteredRestaurants();
    });
  }

  getFilteredRestaurants(): Restaurant[] {
    if (!this.foodItem) {
      return [];
    }
    return this.restaurants.filter(restaurant =>
      restaurant.foodItems.includes(this.foodItem)
    );
  }
}
