import { Component } from '@angular/core';

@Component({
  selector: 'app-restdetails',
  standalone: true,
  imports: [],
  templateUrl: './restdetails.component.html',
  styleUrl: './restdetails.component.css'
})
export class RestdetailsComponent {

}
