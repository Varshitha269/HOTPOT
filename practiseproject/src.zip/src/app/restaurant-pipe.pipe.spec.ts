import { RestaurantPipePipe } from './restaurant-pipe.pipe';

describe('RestaurantPipePipe', () => {
  it('create an instance', () => {
    const pipe = new RestaurantPipePipe();
    expect(pipe).toBeTruthy();
  });
});
